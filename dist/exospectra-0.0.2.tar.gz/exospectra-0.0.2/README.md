# exospectra
A python package to plot transmission spectra of exoplanets using data retrieved from the NASA Exoplanet Archive.
