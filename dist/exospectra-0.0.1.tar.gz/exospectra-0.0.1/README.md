# exospectra
A python package to produce transmission spectra of exoplanets from raw pixel data
