from setuptools import setup

setup(
    name='exospectra',
    version='0.0.1',
    packages=['exospectra'],
    install_requires=[
        'numpy',
        'matplotlib',
    ],
)