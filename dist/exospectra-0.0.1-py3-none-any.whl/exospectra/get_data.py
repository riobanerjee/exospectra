from astroquery.nasa_exoplanet_archive import NasaExoplanetArchive
NasaExoplanetArchive.query_object("WASP-12 b")

# class Getter:

# 	def __init__(self):
# 		pass
